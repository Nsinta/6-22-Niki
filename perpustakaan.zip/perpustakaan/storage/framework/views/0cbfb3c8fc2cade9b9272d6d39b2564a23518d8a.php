

<?php $__env->startSection('container'); ?>
    <h1> Halaman About </h1>
    <h3> <?= $nama; ?> </h3>
    <p> <?= $email; ?> </p>
    <img src="img/<?= $gambar; ?>" alt="<?= $nama; ?>" width="200px">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\perpustakaan\resources\views/About.blade.php ENDPATH**/ ?>