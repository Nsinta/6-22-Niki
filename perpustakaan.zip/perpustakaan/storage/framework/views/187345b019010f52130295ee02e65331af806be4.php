

<?php $__env->startSection('container'); ?>
  <h1>Halaman Gallery</h1>
<?php $__env->stopSection(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Niki SintAS | Gallery</title>
</head>
</html>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\perpustakaan\resources\views/Gallery.blade.php ENDPATH**/ ?>